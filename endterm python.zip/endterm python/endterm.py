def calculateGPA(m,ch,en,m_credit,ch_credit,en_credit):
    print("\nYour overall GPA: ")
    gpa=m*m_credit+ch*ch_credit+en*en_credit
    gpa=gpa/(m_credit+ch_credit+en_credit)

    if 0.7<gpa<1.0:
        gpa=1
    elif 1.0<gpa<1.3:
        gpa=1.3
    elif 1.3<gpa<1.7:
        gpa=1.7
    elif 1.7<gpa<2.0:
        gpa=2.0
    elif 2.0<gpa<2.3:
        gpa=2.3
    elif 2.3<gpa<2.7:
        gpa=2.7
    elif 2.7<gpa<3.0:
        gpa=3.0
    elif 3.0<gpa<3.3:
        gpa=3.3
    elif 3.3<gpa<3.7:
        gpa=3.7
    elif 3.7<gpa<4.0:
        gpa=4.0
    elif 4.0<gpa<4.3:
        gpa=4.3
    if 0<gpa<4.3:
        print(gpa)
    else:
        print('Error')

def translateLetter(*letters):
    gpa_points = []
    for letter in letters:
        if letter == 'A+':
            gpa_points.append(4.3)
        elif letter == 'A':
            gpa_points.append(4.0)
        elif letter == 'A-':
            gpa_points.append(3.7)
        elif letter == 'B+':
            gpa_points.append(3.3)
        elif letter == 'B':
            gpa_points.append(3.0)
        elif letter == 'B-':
            gpa_points.append(2.7)
        elif letter == 'C+':
            gpa_points.append(2.3)
        elif letter == 'C':
            gpa_points.append(2.0)
        elif letter == 'C-':
            gpa_points.append(1.7)
        elif letter == 'D+':
            gpa_points.append(1.3)
        elif letter == 'D':
            gpa_points.append(1.0)
        elif letter == 'D-':
            gpa_points.append(0.7)
    print("\nYour GPA points: ")
    print(gpa_points)

def translatePercentage(*percentages):
    points = []
    for percentage in percentages:
        if 95 <= percentage <= 100:
            points.append(4.3)
        elif 90 <= percentage <= 94:
            points.append(4.0)
        elif 85 <= percentage <= 89:
            points.append(3.7)
        elif 80 <= percentage <= 84:
            points.append(3.3)
        elif 75 <= percentage <= 79:
            points.append(3.0)
        elif 70 <= percentage <= 74:
            points.append(2.7)
        elif 65 <= percentage <= 69:
            points.append(2.3)
        elif 60 <= percentage <= 64:
            points.append(2.0)
        elif 55 <= percentage <= 59:
            points.append(1.7)
        elif 50 <= percentage <= 54:
            points.append(1.3)
        elif 45 <= percentage <= 49:
            points.append(1.0)
        elif 40 <= percentage <= 44:
            points.append(0.7)
    print("\nTranslated Letters:")
    print(points)




calculateGPA(3.3, 2.7, 4,
             4,    3,  4)
translateLetter('A+','B','C')
translatePercentage(100,45,55,89)

#Task 2
def translate_Letter(letter):
    translation_table = {
        'A+': 4.3, 'A': 4.0, 'A-': 3.7,
        'B+': 3.3, 'B': 3.0, 'B-': 2.7,
        'C+': 2.3, 'C': 2.0, 'C-': 1.7,
        'D+': 1.3, 'D': 1.0, 'D-': 0.7
    }
    if letter in translation_table:
        return translation_table[letter]
    else:
        return 0.0  

def calculate_GPA(scores, credits):
    total_points = 0
    total_credits = sum(credits)
    
    for score, credit in zip(scores, credits):
        total_points += translate_Letter(score) * credit
    
    if total_credits != 0:
        return round(total_points / total_credits, 2)
    else:
        return 0.0
credits_file_path = "credits.txt"
credits_data = []
with open(credits_file_path, 'r') as credits_file:
    for line in credits_file:
        data = line.strip().split()
        if len(data) == 2 and data[1].isdigit():
            credits_data.append(int(data[1]))

course_names = ['math', 'chemistry', 'english']
overall_GPAs = []
for course_name in course_names:
    course_scores_file_path = f"{course_name}.txt"
    scores_data = []
    with open(course_scores_file_path, 'r') as scores_file:
        for line in scores_file:
            scores_data.append(line.strip())
    

    gpa = calculate_GPA(scores_data, credits_data)
    overall_GPAs.append(f"{course_name}: {gpa}")

overall_GPAs_file_path = "overallGPAs.txt"
with open(overall_GPAs_file_path, 'w') as overall_file:
    overall_file.write("\n".join(overall_GPAs))

print("Overall GPAs saved to 'overallGPAs.txt'")
print("\n")


#Task 3
class Student:
    def __init__(self, name, num_courses, scores):
        self.name = name
        self.num_courses = num_courses
        self.scores = scores
        self.overall_GPA = None
        self.status = None

    def calculGPA(self):
        total_points = 0
        total_credits = 0

        for course in self.scores:
            score = self.scores[course]['score']
            credits = self.scores[course]['credits']
            total_points += score * credits
            total_credits += credits

        if total_credits != 0:
            self.overall_GPA = round(total_points / total_credits, 2)
        else:
            self.overall_GPA = 0.0
        
        self.setStatus()

    def setStatus(self):
        if self.overall_GPA is not None:
            if self.overall_GPA >= 1.0:
                self.status = "Passed"
            else:
                self.status = "Not Passed"

    def showGPA(self):
        if self.overall_GPA is not None:
            print(f"GPA for {self.name}: {self.overall_GPA}")
        else:
            print("GPA not calculated yet.")

    def showStatus(self):
        if self.status is not None:
            print(f"Status for {self.name}: {self.status}")
        else:
            print("Status not available yet.")

scores = {
    'Math': {'score': 4.3, 'credits': 4},
    'Chemistry': {'score': 3.3, 'credits': 3},
    'English': {'score': 4.0, 'credits': 4}
}

student1 = Student("Alice", 3, scores)
student1.calculGPA()
student1.showGPA()
student1.showStatus()
